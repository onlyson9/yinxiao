(function () {
'use strict';

const audioMap = {
    "shoot-1-B4Ou7JVe0000": "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/carawm2.mp3",
    "15-CHebb":               "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/zqbaotou3.mp3",

    // �� kill4�����飬�����������һ������Ӿ�����ӣ�
    "kill4": [
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/zhandi52.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/204212.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/20422.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod612.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod1621.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod211.mp3",
    ],

    // �� kill7�����飬�����������һ������Ӿ�����ӣ�
    "kill7": [
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/kill9.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/kill22.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/zhandi52.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/204212.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/20422.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod612.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod1621.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod211.mp3",
        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/zhandi61.mp3"
    ],
    "kill400000":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cod211.mp3",
    "AWM%20Draw":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/awplashuan1.mp3",
    "Draw":               "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/fuhuo.mp3",
    "shoot-1-CUe":          "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/ak9.mp3",
    "shoot-2-DM":           "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/ak9.mp3",
    "8-yOVI0000":               "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/jizhong13.mp3",
    "AKM%20Cocking":        "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/aklasuan.mp3",
    "shoot-2-D02":          "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/car.mp3",
    "M16%20Single%20Shot%": "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/heiqishi.mp3",
    "D9iwdnrv":             "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/heiqishi4.mp3",
    "20Cocking-Cq_Yi_AE":             "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/aklasuan.mp3",
    "AKM%20Mag%20Out-DWOYmd7e": "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/cfleishen3.mp3",
    "AWM%20Mag%20IN-9CHq1LhT":  "https://cryzen.io/assets/AKM%20Mag%20IN-HByT7WhJ.mp3",
    "draw-C15P":  "https://cryzen.io/assets/take-BVB2SIm_.mp3",
    "ladder":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/boom1.mp3",
    "shoot-Bo40":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/gaya1.mp3",
    "explosion-CJ":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/gaya1.mp3",
    "shoot-CnEX":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/car.mp3",
    "kill2000":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/tishi.mp3",
    "1-IeZ1nX":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/concrete_ct_01.mp3",
    "2-DKrG1SdN":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/concrete_ct_02.mp3",
    "3-HIWJ68z":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/concrete_ct_03.mp3",
    "4-BnRZq":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/concrete_ct_04.mp3",
    "AWM%20Cocking-Cidf1B":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/awplashuan1.mp3",
    "5-Qyvt":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/awplashuan111111111111111.mp3",
    "shoot-DyQbG":  "https://cdn.jsdelivr.net/gh/onlyson9/yinxiao@main/ak8.mp3",
};

const PASSTHROUGH = ["Glock%20Draw", "Butterfly%20Draw"];
const audioCache = new Map();   // key: ÿ�� url

// ���ѡ���������ȡһ�����ַ���ԭ������
const pick = v => Array.isArray(v) ? v[Math.floor(Math.random() * v.length)] : v;

async function preloadAudio() {
    const urls = new Set();
    for (const val of Object.values(audioMap)) {
        for (const u of [].concat(val)) urls.add(u);
    }
    for (const url of urls) {
        try {
            const res = await fetch(url);
            const buf = await res.arrayBuffer();
            audioCache.set(url, buf);
        } catch (e) {}
    }
}
preloadAudio();

const originalFetch = window.fetch;
window.fetch = async function (input, init) {
    const url = (typeof input === 'string' ? input : input?.url) ?? '';
    if (PASSTHROUGH.some(k => url.includes(k))) return originalFetch.apply(this, arguments);
    for (const [key, val] of Object.entries(audioMap)) {
        if (url.includes(key)) {
            const buf = audioCache.get(pick(val));
            if (buf) return new Response(buf.slice(0), { status: 200, headers: { 'Content-Type': 'audio/mpeg' } });
        }
    }
    return originalFetch.apply(this, arguments);
};

})();